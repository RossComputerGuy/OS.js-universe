<?php namespace OSjs\Packages;

use OSjs\Core\Request;

class EXAMPLE {
}

return "OSjs\\Packages\\EXAMPLE";